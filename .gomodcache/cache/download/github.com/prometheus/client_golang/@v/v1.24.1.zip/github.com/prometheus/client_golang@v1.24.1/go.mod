module github.com/prometheus/client_golang

go 1.25.0

require (
	github.com/beorn7/perks v1.0.1
	github.com/cespare/xxhash/v2 v2.3.0
	github.com/google/go-cmp v0.7.0
	github.com/json-iterator/go v1.1.12
	github.com/klauspost/compress v1.19.1
	github.com/kylelemons/godebug v1.1.0
	github.com/prometheus/client_model v0.6.2
	github.com/prometheus/common v0.70.1
	github.com/prometheus/procfs v0.21.1
	go.uber.org/goleak v1.3.0
	golang.org/x/sys v0.47.0
	google.golang.org/protobuf v1.36.11
)

require (
	github.com/golang-jwt/jwt/v5 v5.3.1 // indirect
	github.com/google/uuid v1.6.0 // indirect
	github.com/jpillora/backoff v1.0.0 // indirect
	github.com/modern-go/concurrent v0.0.0-20180306012644-bacd9c7ef1dd // indirect
	github.com/modern-go/reflect2 v1.0.2 // indirect
	github.com/munnerz/goautoneg v0.0.0-20191010083416-a7dc8b61c822 // indirect
	github.com/mwitkow/go-conntrack v0.0.0-20190716064945-2f068394615f // indirect
	go.yaml.in/yaml/v2 v2.4.4 // indirect
	golang.org/x/net v0.57.0 // indirect
	golang.org/x/oauth2 v0.36.0 // indirect
	golang.org/x/text v0.40.0 // indirect
)

exclude github.com/prometheus/client_golang v1.12.1
